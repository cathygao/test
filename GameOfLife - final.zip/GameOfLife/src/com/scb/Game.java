package com.scb;

public class Game {
	private int[][] array;
	private int wide;
	private int hight;

	public Game(int hight, int wide) {
		this.wide = wide;
		this.hight = hight;
	}

	public void setStatus(int[][] map2) {
		array = map2;
	}
	
	private boolean isBoundary(int i, int j){
		/* 
		 * judge if the point(i,j) is the boundary one
		 */
		if( 0 == i || hight == (i+1) || 0 == j || wide == (j+1) )
			return true;
		else
			return false;
	}

	public int numNeighbour(int i, int j) {
		
		int neiSum = 0;
		int rowStart = i - 1, rowEnd = i + 1;
		int colStart = j - 1, colEnd = j + 1;
		
		/*
		 * the edge of the map has different cyclic boundary condition
		 */
		if (0 == i) {
			rowStart = i;
		}
		if(0 == (i + 1) % hight){
			rowEnd = i;
		}
		if(0 == j){
			colStart = j;
		}
		if(0 == (j + 1) % wide){
			colEnd = j;
		}

		for (int k1 = rowStart; k1 <= rowEnd; k1++) {
			for (int k2 = colStart; k2 <= colEnd; k2++) {
				if (!(k1 == i && k2 == j) && (array[k1][k2] == 1)) {
					neiSum++;
				}
			}
		}
		return neiSum;
	}

	public int calNextStatus(int i, int j) {
		if( true == isBoundary(i,j) ){
			/* 
			 * the boundary point should always be dead.
			 */
			return 0;
		}
		else if( 1 == array[i][j] && numNeighbour(i,j) <= 1 )
		{
			return 0;
		}
		else if( 1 == array[i][j] && numNeighbour(i,j) > 3 ) 
		{
			return 0;
		}
		else if( 0 == array[i][j] && 3 == numNeighbour(i,j) )
		{
			return 1;
		}
		else
		{
			return array[i][j]; 
		}
	}
	
	public String nextStatus(){
		String str ="";
		for(int i = 0 ; i < hight ; i++ )
			for(int j = 0 ; j < wide ; j++)
			{
				str+=(char)(calNextStatus(i,j)+(int)'0');
			}
		return str;
	}

}
